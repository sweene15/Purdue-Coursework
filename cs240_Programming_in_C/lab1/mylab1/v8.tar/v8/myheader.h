float mycalc(float, float);
